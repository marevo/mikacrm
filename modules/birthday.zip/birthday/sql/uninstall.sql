DELETE FROM menu WHERE `title`='Birthdays';
DELETE FROM modules WHERE name="birthdays";